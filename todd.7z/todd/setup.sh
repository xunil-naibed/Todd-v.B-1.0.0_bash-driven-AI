#******************************************************************
#!/bin/bash
#******************************************************************
clear

# Function to check if espeak-ng is installed
function check_espeak_ng() {
    if command -v espeak-ng &> /dev/null; then
        echo "espeak-ng is already installed."
    else
        echo "espeak-ng is not installed. Installing now..."
        
        # Attempt to install espeak-ng (Debian/Ubuntu based command)
        if sudo apt update && sudo apt install -y espeak-ng; then
            echo "espeak-ng installed successfully."
        else
            echo "Installation of espeak-ng failed. Please install it manually and try again."
            exit 1  # Exit the script if installation fails
        fi
    fi
}

# Run the check function
check_espeak_ng

#******************************************************************
SNIPPET='
#******************************************************************
# Check if the TODDrc file exists and source it
if [ -f "$HOME/todd/self/.TODDrc" ]; then
    . "$HOME/todd/self/.TODDrc"  # Source the configuration file
fi
#******************************************************************
'
    echo "scanning sources ..."
# Check if the snippet is already in the .bashrc file
if ! grep -q 'Check if the TODDrc file exists and source it' "$HOME/.bashrc"; then
    # Append the snippet to the .bashrc file
    echo "$SNIPPET" >> "$HOME/.bashrc"
    echo "a duality-link has been added to .bashrc"
else
    echo "a duality-link already exists in .bashrc"
fi
echo ''
# Source the .bashrc to apply changes immediately
source "$HOME/.bashrc"
echo ".bashrc and .TODDrc files have been linked successfully."
echo '' 