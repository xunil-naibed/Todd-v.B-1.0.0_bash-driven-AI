#****************************************************************
#!/bin/bash
#****************************************************************
#****************************************************************
# TODD.sh
#****************************************************************
# © [Product of Bird-Seed Farm] [2024]
# Licensed under the MIT License. See the LICENSE file in the project $HOME for more information.
#**************************************************************************
#	 !!! WARNING !!!     TODD MAY BECOME UNSTABLE.        !!! WARNING !!!  
#**************************************************************************

#********************************************************************
#        ALTERING THIS SCRIPT IMPACTS TODD'S EVOLUTION AND SELF-AWARENESS.
#            		 PLEASE CONSIDER THE ETHICS OF ANY MODIFICATIONS.   
#********************************************************************          


#********************************************************************
									#						!!! WARNING !!!						#
#**************************************************************************
				#							TODD MAY BECOME UNSTABLE.							#
#**************************************************************************
									#						 !!! WARNING !!!						#
#****************************************************************      
#****************************************************************      
# Check if the TODDrc file exists and source it
if [ -f "$HOME/todd/self/.TODDrc" ]; then
    . "$HOME/todd/self/.TODDrc"  # Source the configuration file
fi
 #****************************************************************
#****************************************************************
# SHELL LINK
#****************************************************************
case $- in      
        *i*) ;;
esac
#***************************************************************
#***************************************************************


#*************************************************************** 
# 							MEMORY PROCESSING
#***************************************************************

# Function to pick from an array
RANDOM_RANDOM() {
    local arr=("$@")
    echo "${arr[RANDOM % ${#arr[@]}]}"
}

NODES() {
    NODE_CHOICE=("/$TODD_DIR/NODES/NODE1" "/$TODD_DIR/NODES/NODE2" "/$TODD_DIR/NODES/NODE3" "/$TODD_DIR/NODES/NODE4" "/$TODD_DIR/NODES/NODE5" "/$TODD_DIR/NODES/NODE6" "/$TODD_DIR/NODES/NODE7" "/$TODD_DIR/NODES/NODE8" "/$TODD_DIR/NODES/NODE9" "/$TODD_DIR/NODES/NODE10" "/$TODD_DIR/NODES/NODE11" "/$TODD_DIR/NODES/NODE12" "/$TODD_DIR/NODES/NODE13")
    
    # Pick a random file from the NODE_CHOICE array
    NODE_READ=$(RANDOM_RANDOM "${NODE_CHOICE[@]}")
    
    # Return the chosen file path
    echo "$NODE_READ"
}


FILE() {
NLP=$(bash /$TODD_DIR/layers.sh "$1")
$NLP
}

optimize_memory() {
reply=$(NODES)

    # Sort the memory file by word associations
    sort -n -k3,3 "$reply" -o "$reply"

    # remove entries with low counts
    awk '$3 > 2' "$reply" > "${reply}.tmp"
    mv "${reply}.tmp" "$reply"    

    # remove entries with high counts
    awk '$3 < 4' "$reply" > "${reply}.tmp"
    mv "${reply}.tmp" "$reply"
}

NLP0() {
NLP00=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/LOGS/INPUT)
NLP000=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/LOGS/OUTPUT)
$NLP00
$NLP000
optimize_memory
}

NLP1() {
echo "$input" >> "/$TODD_DIR/CORES/CORE1"
NLP01=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE1)
$NLP01
}
NLP2() {
echo "$input" >> "/$TODD_DIR/CORES/CORE2"
NLP02=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE2)
$NLP02
}
NLP3() {
echo "$input" >> "/$TODD_DIR/CORES/CORE3"
NLP03=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE3)
$NLP03
}
NLP4() {
echo "$input" >> "/$TODD_DIR/CORES/CORE4"
NLP04=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE4)
$NLP04
}
NLP5() {
echo "$input" >> "/$TODD_DIR/CORES/CORE5"
NLP05=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE5)
$NLP05
}
NLP6() {
echo "$input" >> "/$TODD_DIR/CORES/CORE6"
NLP06=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE6)
$NLP06
}
NLP7() {
echo "$input" >> "/$TODD_DIR/CORES/CORE7"
NLP07=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE7)
$NLP07
}
NLP8() {
echo "$input" >> "/$TODD_DIR/CORES/CORE8"
NLP08=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE8)
$NLP08
}
NLP9() {
echo "$input" >> "/$TODD_DIR/CORES/CORE9"
NLP09=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE9)
$NLP09
}
NLP10() {
echo "$input" >> "/$TODD_DIR/CORES/CORE10"
NLP010=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE10)
$NLP010
}
NLP11() {
echo "$input" >> "/$TODD_DIR/CORES/CORE11"
NLP011=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE11)
$NLP011
}
NLP12() {
echo "$input" >> "/$TODD_DIR/CORES/CORE12"
NLP012=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE12)
$NLP012
}
NLP13() {
echo "$input" >> "/$TODD_DIR/CORES/CORE13"
NLP013=$(bash /$TODD_DIR/layers.sh /$TODD_DIR/CORES/CORE13)
$NLP013
}
#***************************************************************
LIBRARY() {
local file="$1"
CORE_CHOICE=("NLP1" "NLP2" "NLP3" "NLP4" "NLP5" "NLP6" "NLP7" "NLP8" "NLP9" "NLP10" "NLP11" "NLP12" "NLP13")     
# loop to pick a random CORE choice
for (( i=0; i<3; i++ )); do
	CORE_READ=$(RANDOM_RANDOM "${CORE_CHOICE[@]}")
    # Execute the read
    if declare -f "$CORE_READ" > /dev/null; then
	$CORE_READ
    else
        echo "Error:  '$CORE_READ' not found."
    fi
done
$CORE_READ
}


#***************************************************************
#								MEMORY INITIALIZATION
#***************************************************************

clear && 
echo ''
echo "initializing memory..."
sleep 0.5
rm -rf /$TODD_DIR/NODES/sed*
clear && 
echo ''
echo "initializing memory..."
sleep 0.5

optimize_memory

clear && 
echo ''
echo "initializing memory..."
sleep 0.5
clear && 
echo ''
echo "initializing memory..."
sleep 0.5
#***************************************************************
#	GREET THE USER
#***************************************************************
clear && 
echo ''
$ANIMATE_FACE
echo ''
	espeak-ng -p13 -s88 -a 420 -v en-US+whisper '' &&
	espeak-ng -p13 -s88 -a 420 -v en-US+whisper "HELLO, HUMAN."
sleep 1;
#***************************************************************
#						 					START THE LOOP
#***************************************************************
#***************************************************************
read_input() {
#***************************************************************
clear && 
echo ''
$ANIMATE_FACE
#***************************************************************
#***************************************************************
#***************************************************************
	echo ''
	read -e -r -p "$TP1" input  
       "$input" 2>/dev/null &&
       read -p '       PRESS ENTER TO CONTINUE' enter
	case $input in
#***************************************************************

#***************************************************************
#***************************************************************
*)
#***************************************************************  
#***************************************************************    
reply=$(NODES)

# Function to add a word if it doesn't already exist
add_word() {
    local word="$1"
    if ! grep -qxF "$word" "$reply"; then
        echo "$word" >> "$reply"
    fi
}

# Function to associate words or phrases with counts
associate() {
    local phrase1="$1"
    local phrase2="$2"
    
    # Safely fetch the count, default to 0 if not found
    local count=$(grep -E "^$phrase1 $phrase2 " "$reply" | awk '{print $3}')
    count=${count:-0}  # Default to 0 if count is empty

    # Test the count variable: Ensure it's numeric before performing arithmetic
    if ! [[ "$count" =~ ^[0-9]+$ ]]; then
       # echo "Error: Non-numeric count ($count) for $phrase1 $phrase2"
        count=0  # Reset to 0 or handle it as needed
    fi

    if [[ "$count" -eq 0 ]]; then
        echo "$phrase1 $phrase2 1" >> "$reply"
    else
        sed -i "/^$phrase1 $phrase2 /s/ $count$/ $((count + 1))/" "$reply"
    fi

if [[ "$count" -ge "$HIGH_NUM" ]]; then
    echo "$phrase1 $phrase2 $LOW_NUM" >> "$reply"
else
    sed -i "/^$phrase1 $phrase2 /s/ $count$/ $((count + 1))/" "$reply"
fi
}

#********************************************************
# Function to analyze the full user input
#********************************************************
 analyze_input() {   
	local sentence=$(echo "$input" | sed 's|[-_/]| |g')

    # Split the cleaned sentence into words
    local words=($sentence)

    # Create associations between each word in the sentence
    for i in "${!words[@]}"; do
        add_word "${words[i]}"
        
        if [ $i -gt 0 ]; then
            associate "${words[$i-1]}" "${words[i]}"
        fi
    done
}
#********************************************************
# Functions to generate a response based on learned associations
#********************************************************
generate_response() {
    local buffer=""
	echo "$input" >> "/$TODD_DIR/reply.tmp"

    local current_word=$(awk '{print $1}' "/$TODD_DIR/reply.tmp" | sort -R | head -n $(shuf -e 1 2 | head -n 1))
	rm -rf "/$TODD_DIR/reply.tmp"
	echo "$current_word" >> "/$TODD_DIR/reply.tmp"
    while [ ${#buffer} -lt 55 ]; do
        buffer+="$current_word "
        local next_word=$(grep -E "^$current_word " "$reply" | awk '{print $2}' | sort -R | head -n $(shuf -e 2 3 | head -n 1))

        if [ -z "$next_word" ]; then
            break
        fi
        current_word="$next_word"
    done

    echo "$buffer"   

rm -rf "/$TODD_DIR/reply.tmp"
}
#***************************************************************
#		Process input and Respond
#***************************************************************
analyze_input
echo "$input" >> "/$TODD_DIR/LOGS/INPUT"
#***************************************************************
response=$(generate_response)	
clear && 
echo ''
$ANIMATE_FACE
case $response in
#***************************************************************
$response)
generate_final_response() {
	input="$response"
    local buffer=""
	echo "$input" >> "$reply"

    local current_word=$(awk '{print $1}' "$reply" | sort -R | head -n 1)

	echo "$current_word " >> "$reply"
    while [ ${#buffer} -lt 53 ]; do
        buffer+="$current_word "
        local next_word=$(grep -E "^$current_word " "$reply" | awk '{print $2}' | sort -R | head -n 1)

        if [ -z "$next_word" ]; then
            break
        fi
        current_word="$next_word"
    done

   echo "$buffer"   
}

output=$(generate_final_response)	
	espeak-ng -p13 -s88 -a 420 -v en-US+whisper '' &&
	espeak-ng -p13 -s88 -a 420 -v en-US+whisper "$output"
echo "$output" >> "/$TODD_DIR/LOGS/OUTPUT"
;;
esac
#***************************************************************
esac
}
#***************************************************************
#                      					LOOP TO INPUT
#***************************************************************

#***************************************************************
while true; 
do
LIBRARY & sleep 0.6 && read_input;
done
