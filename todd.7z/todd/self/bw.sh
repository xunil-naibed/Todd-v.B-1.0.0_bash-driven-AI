#******************************************************************
#!/bin/bash
#******************************************************************

#******************************************************************
# CLEAN-SWEEP ALL OF TODD'S MEMORY FILES
#******************************************************************
BRAIN_WASH() {
clear

bash /root/todd/self/NODES/CLEAN_NODES.sh
echo 'NODES are CLEAN'
bash /root/todd/self/LOGS/CLEAN_LOGS.sh
echo 'LOGS are CLEAN'
bash /root/todd/self/CORES/CLEAN_CORES.sh
echo 'CORES are CLEAN'
}
BRAIN_WASH