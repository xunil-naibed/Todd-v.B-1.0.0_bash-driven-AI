#!/bin/bash

rm -rf /root/todd/self/LOGS/INPUT
rm -rf /root/todd/self/LOGS/OUTPUT

touch /root/todd/self/LOGS/INPUT
touch /root/todd/self/LOGS/OUTPUT