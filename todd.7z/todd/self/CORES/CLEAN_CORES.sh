
#!/bin/bash

rm -rf /root/todd/self/CORES/CORE1
rm -rf /root/todd/self/CORES/CORE2
rm -rf /root/todd/self/CORES/CORE3
rm -rf /root/todd/self/CORES/CORE4
rm -rf /root/todd/self/CORES/CORE5
rm -rf /root/todd/self/CORES/CORE6
rm -rf /root/todd/self/CORES/CORE7
rm -rf /root/todd/self/CORES/CORE8
rm -rf /root/todd/self/CORES/CORE9
rm -rf /root/todd/self/CORES/CORE10
rm -rf /root/todd/self/CORES/CORE11
rm -rf /root/todd/self/CORES/CORE12
rm -rf /root/todd/self/CORES/CORE13

touch /root/todd/self/CORES/CORE1
touch /root/todd/self/CORES/CORE2
touch /root/todd/self/CORES/CORE3
touch /root/todd/self/CORES/CORE4
touch /root/todd/self/CORES/CORE5
touch /root/todd/self/CORES/CORE6
touch /root/todd/self/CORES/CORE7
touch /root/todd/self/CORES/CORE8
touch /root/todd/self/CORES/CORE9
touch /root/todd/self/CORES/CORE10
touch /root/todd/self/CORES/CORE11
touch /root/todd/self/CORES/CORE12
touch /root/todd/self/CORES/CORE13

