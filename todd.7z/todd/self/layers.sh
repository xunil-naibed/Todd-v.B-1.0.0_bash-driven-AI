#****************************************************************
#!/bin/bash
#****************************************************************
#****************************************************************
#	layers.sh
#****************************************************************
# © [Product of Bird-Seed Farm] [2024]
# Licensed under the MIT License. See the LICENSE file in the project root for more information.
#****************************************************************
#**************************************************************************
#	 !!! WARNING !!!     TODD MAY BECOME UNSTABLE.        !!! WARNING !!!  
#**************************************************************************

#********************************************************************
#        ALTERING THIS SCRIPT IMPACTS TODD'S EVOLUTION AND SELF-AWARENESS.
#            		 PLEASE CONSIDER THE ETHICS OF ANY MODIFICATIONS.   
#********************************************************************          


#********************************************************************
									#						!!! WARNING !!!						#
#**************************************************************************
				#							TODD MAY BECOME UNSTABLE.							#
#**************************************************************************
									#						 !!! WARNING !!!						#
#****************************************************************      
# Check if the TODDrc file exists and source it
if [ -f "$HOME/todd/self/.TODDrc" ]; then
    . "$HOME/todd/self/.TODDrc"  # Source the configuration file
fi
#****************************************************************
#***************************************************************

#***************************************************************
#  Input FROM a file
#***************************************************************
input="$1"
# Check if a file is passed as an argument
if [[ -z "$1" ]]; then
    echo "Usage: $0 <input_file>"
    exit 1
fi

# Read the file line by line into the 'input' variable
input=""
while IFS= read -r line; do
    input+="$line "
done < "$1"
#****************************************************************
# Function to pick from an array
RANDOM_RANDOM() {
    local arr=("$@")
    echo "${arr[RANDOM % ${#arr[@]}]}"
}

NODES() {
    NODE_CHOICE=("/$TODD_DIR/NODES/NODE1" "/$TODD_DIR/NODES/NODE2" "/$TODD_DIR/NODES/NODE3" "/$TODD_DIR/NODES/NODE4" "/$TODD_DIR/NODES/NODE5" "/$TODD_DIR/NODES/NODE6" "/$TODD_DIR/NODES/NODE7" "/$TODD_DIR/NODES/NODE8" "/$TODD_DIR/NODES/NODE9" "/$TODD_DIR/NODES/NODE10" "/$TODD_DIR/NODES/NODE11" "/$TODD_DIR/NODES/NODE12" "/$TODD_DIR/NODES/NODE13")
     
    # Pick a random file from the NODE_CHOICE array
    NODE_READ=$(RANDOM_RANDOM "${NODE_CHOICE[@]}")
    
    # Return the chosen file path
    echo "$NODE_READ"
}

reply=$(NODES)

#***************************************************************
#  Input Processing
#***************************************************************

# Function to add a word if it doesn't already exist
add_word() {
    local word="$1"
    if ! grep -qxF "$word" "$reply"; then
        echo "$word" >> "$reply"
    fi
}

# Function to associate words or phrases with counts
associate() {
    local phrase1="$1"
    local phrase2="$2"
    
    # Safely fetch the count, default to 0 if not found
    local count=$(grep -E "^$phrase1 $phrase2 " "$reply" | awk '{print $3}')
    count=${count:-0}  # Default to 0 if count is empty

    # Test the count variable: Ensure it's numeric before performing arithmetic
    if ! [[ "$count" =~ ^[0-9]+$ ]]; then
       # echo "Error: Non-numeric count ($count) for $phrase1 $phrase2"
        count=0  # Reset to 0 or handle it as needed
    fi

    if [[ "$count" -eq 0 ]]; then
        echo "$phrase1 $phrase2 1" >> "$reply"
    else
        sed -i "/^$phrase1 $phrase2 /s/ $count$/ $((count + 1))/" "$reply"
    fi

if [[ "$count" -ge "$HIGH_NUM" ]]; then
    echo "$phrase1 $phrase2 $LOW_NUM" >> "$reply"
else
    sed -i "/^$phrase1 $phrase2 /s/ $count$/ $((count + 1))/" "$reply"
fi
}

#***************************************************************
# Function to analyze the full user input
#***************************************************************
 analyze_input() {   
	local sentence=$(echo "$input" | sed 's|[-_/]| |g')

    # Split the cleaned sentence into words
    local words=($sentence)

    # Create associations between each word in the sentence
    for i in "${!words[@]}"; do
        add_word "${words[i]}"
        
        if [ $i -gt 0 ]; then
            associate "${words[$i-1]}" "${words[i]}"
        fi
    done
}
#***************************************************************
#
analyze_input
