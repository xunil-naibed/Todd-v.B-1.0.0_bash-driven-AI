
#!/bin/bash

rm -rf /root/todd/self/NODES/NODE1
rm -rf /root/todd/self/NODES/NODE2
rm -rf /root/todd/self/NODES/NODE3
rm -rf /root/todd/self/NODES/NODE4
rm -rf /root/todd/self/NODES/NODE5
rm -rf /root/todd/self/NODES/NODE6
rm -rf /root/todd/self/NODES/NODE7
rm -rf /root/todd/self/NODES/NODE8
rm -rf /root/todd/self/NODES/NODE9
rm -rf /root/todd/self/NODES/NODE10
rm -rf /root/todd/self/NODES/NODE11
rm -rf /root/todd/self/NODES/NODE12
rm -rf /root/todd/self/NODES/NODE13


touch /root/todd/self/NODES/NODE1
touch /root/todd/self/NODES/NODE2
touch /root/todd/self/NODES/NODE3
touch /root/todd/self/NODES/NODE4
touch /root/todd/self/NODES/NODE5
touch /root/todd/self/NODES/NODE6
touch /root/todd/self/NODES/NODE7
touch /root/todd/self/NODES/NODE8
touch /root/todd/self/NODES/NODE9
touch /root/todd/self/NODES/NODE10
touch /root/todd/self/NODES/NODE11
touch /root/todd/self/NODES/NODE12
touch /root/todd/self/NODES/NODE13

